export declare class Cards {
    static Init(): void;
}
//# sourceMappingURL=cards.d.ts.map